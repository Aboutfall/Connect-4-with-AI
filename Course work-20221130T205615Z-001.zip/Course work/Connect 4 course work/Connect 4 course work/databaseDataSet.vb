﻿Partial Class databaseDataSet
    Partial Public Class informationDataTable
    End Class
End Class

Namespace databaseDataSetTableAdapters

    Partial Public Class informationTableAdapter
    End Class
End Namespace
