﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmconnect4
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.btnRow1 = New System.Windows.Forms.Button()
        Me.btnrow2 = New System.Windows.Forms.Button()
        Me.btnrow3 = New System.Windows.Forms.Button()
        Me.btnrow4 = New System.Windows.Forms.Button()
        Me.btnrow5 = New System.Windows.Forms.Button()
        Me.btnrow6 = New System.Windows.Forms.Button()
        Me.btnrow7 = New System.Windows.Forms.Button()
        Me.PictureBox7_0 = New System.Windows.Forms.PictureBox()
        Me.PictureBox6_0 = New System.Windows.Forms.PictureBox()
        Me.PictureBox7_1 = New System.Windows.Forms.PictureBox()
        Me.PictureBox6_1 = New System.Windows.Forms.PictureBox()
        Me.PictureBox7_2 = New System.Windows.Forms.PictureBox()
        Me.PictureBox7_3 = New System.Windows.Forms.PictureBox()
        Me.PictureBox6_3 = New System.Windows.Forms.PictureBox()
        Me.PictureBox7_4 = New System.Windows.Forms.PictureBox()
        Me.PictureBox6_2 = New System.Windows.Forms.PictureBox()
        Me.PictureBox6_4 = New System.Windows.Forms.PictureBox()
        Me.PictureBox7_5 = New System.Windows.Forms.PictureBox()
        Me.PictureBox6_5 = New System.Windows.Forms.PictureBox()
        Me.PictureBox4_0 = New System.Windows.Forms.PictureBox()
        Me.PictureBox5_1 = New System.Windows.Forms.PictureBox()
        Me.PictureBox5_2 = New System.Windows.Forms.PictureBox()
        Me.PictureBox5_3 = New System.Windows.Forms.PictureBox()
        Me.PictureBox5_4 = New System.Windows.Forms.PictureBox()
        Me.PictureBox5_5 = New System.Windows.Forms.PictureBox()
        Me.PictureBox5_0 = New System.Windows.Forms.PictureBox()
        Me.PictureBox4_1 = New System.Windows.Forms.PictureBox()
        Me.PictureBox4_2 = New System.Windows.Forms.PictureBox()
        Me.PictureBox4_3 = New System.Windows.Forms.PictureBox()
        Me.PictureBox4_4 = New System.Windows.Forms.PictureBox()
        Me.PictureBox4_5 = New System.Windows.Forms.PictureBox()
        Me.PictureBox3_0 = New System.Windows.Forms.PictureBox()
        Me.PictureBox3_1 = New System.Windows.Forms.PictureBox()
        Me.PictureBox3_2 = New System.Windows.Forms.PictureBox()
        Me.PictureBox3_3 = New System.Windows.Forms.PictureBox()
        Me.PictureBox3_4 = New System.Windows.Forms.PictureBox()
        Me.PictureBox3_5 = New System.Windows.Forms.PictureBox()
        Me.PictureBox2_0 = New System.Windows.Forms.PictureBox()
        Me.PictureBox2_1 = New System.Windows.Forms.PictureBox()
        Me.PictureBox2_2 = New System.Windows.Forms.PictureBox()
        Me.PictureBox2_3 = New System.Windows.Forms.PictureBox()
        Me.PictureBox2_4 = New System.Windows.Forms.PictureBox()
        Me.PictureBox2_5 = New System.Windows.Forms.PictureBox()
        Me.PictureBox1_0 = New System.Windows.Forms.PictureBox()
        Me.PictureBox1_1 = New System.Windows.Forms.PictureBox()
        Me.PictureBox1_2 = New System.Windows.Forms.PictureBox()
        Me.PictureBox1_3 = New System.Windows.Forms.PictureBox()
        Me.PictureBox1_4 = New System.Windows.Forms.PictureBox()
        Me.PictureBox1_5 = New System.Windows.Forms.PictureBox()
        Me.lblPlayer1 = New System.Windows.Forms.Label()
        Me.lblPlayer2 = New System.Windows.Forms.Label()
        CType(Me.PictureBox7_0, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox6_0, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox7_1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox6_1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox7_2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox7_3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox6_3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox7_4, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox6_2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox6_4, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox7_5, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox6_5, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox4_0, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox5_1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox5_2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox5_3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox5_4, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox5_5, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox5_0, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox4_1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox4_2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox4_3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox4_4, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox4_5, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox3_0, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox3_1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox3_2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox3_3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox3_4, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox3_5, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox2_0, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox2_1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox2_2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox2_3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox2_4, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox2_5, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox1_0, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox1_1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox1_2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox1_3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox1_4, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox1_5, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'btnRow1
        '
        Me.btnRow1.Location = New System.Drawing.Point(29, 42)
        Me.btnRow1.Name = "btnRow1"
        Me.btnRow1.Size = New System.Drawing.Size(126, 63)
        Me.btnRow1.TabIndex = 0
        Me.btnRow1.Text = "Button1"
        Me.btnRow1.UseVisualStyleBackColor = True
        '
        'btnrow2
        '
        Me.btnrow2.Location = New System.Drawing.Point(161, 42)
        Me.btnrow2.Name = "btnrow2"
        Me.btnrow2.Size = New System.Drawing.Size(126, 63)
        Me.btnrow2.TabIndex = 1
        Me.btnrow2.Text = "Button2"
        Me.btnrow2.UseVisualStyleBackColor = True
        '
        'btnrow3
        '
        Me.btnrow3.Location = New System.Drawing.Point(293, 42)
        Me.btnrow3.Name = "btnrow3"
        Me.btnrow3.Size = New System.Drawing.Size(126, 63)
        Me.btnrow3.TabIndex = 2
        Me.btnrow3.Text = "Button3"
        Me.btnrow3.UseVisualStyleBackColor = True
        '
        'btnrow4
        '
        Me.btnrow4.Location = New System.Drawing.Point(425, 42)
        Me.btnrow4.Name = "btnrow4"
        Me.btnrow4.Size = New System.Drawing.Size(126, 63)
        Me.btnrow4.TabIndex = 3
        Me.btnrow4.Text = "Button4"
        Me.btnrow4.UseVisualStyleBackColor = True
        '
        'btnrow5
        '
        Me.btnrow5.Location = New System.Drawing.Point(557, 42)
        Me.btnrow5.Name = "btnrow5"
        Me.btnrow5.Size = New System.Drawing.Size(126, 63)
        Me.btnrow5.TabIndex = 4
        Me.btnrow5.Text = "Button5"
        Me.btnrow5.UseVisualStyleBackColor = True
        '
        'btnrow6
        '
        Me.btnrow6.Location = New System.Drawing.Point(689, 42)
        Me.btnrow6.Name = "btnrow6"
        Me.btnrow6.Size = New System.Drawing.Size(126, 63)
        Me.btnrow6.TabIndex = 5
        Me.btnrow6.Text = "Button6"
        Me.btnrow6.UseVisualStyleBackColor = True
        '
        'btnrow7
        '
        Me.btnrow7.Location = New System.Drawing.Point(821, 42)
        Me.btnrow7.Name = "btnrow7"
        Me.btnrow7.Size = New System.Drawing.Size(126, 63)
        Me.btnrow7.TabIndex = 6
        Me.btnrow7.Text = "Button7"
        Me.btnrow7.UseVisualStyleBackColor = True
        '
        'PictureBox7_0
        '
        Me.PictureBox7_0.Location = New System.Drawing.Point(821, 515)
        Me.PictureBox7_0.Name = "PictureBox7_0"
        Me.PictureBox7_0.Size = New System.Drawing.Size(126, 70)
        Me.PictureBox7_0.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage
        Me.PictureBox7_0.TabIndex = 47
        Me.PictureBox7_0.TabStop = False
        '
        'PictureBox6_0
        '
        Me.PictureBox6_0.Location = New System.Drawing.Point(689, 515)
        Me.PictureBox6_0.Name = "PictureBox6_0"
        Me.PictureBox6_0.Size = New System.Drawing.Size(126, 70)
        Me.PictureBox6_0.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage
        Me.PictureBox6_0.TabIndex = 46
        Me.PictureBox6_0.TabStop = False
        '
        'PictureBox7_1
        '
        Me.PictureBox7_1.Location = New System.Drawing.Point(821, 439)
        Me.PictureBox7_1.Name = "PictureBox7_1"
        Me.PictureBox7_1.Size = New System.Drawing.Size(126, 70)
        Me.PictureBox7_1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage
        Me.PictureBox7_1.TabIndex = 45
        Me.PictureBox7_1.TabStop = False
        '
        'PictureBox6_1
        '
        Me.PictureBox6_1.Location = New System.Drawing.Point(689, 439)
        Me.PictureBox6_1.Name = "PictureBox6_1"
        Me.PictureBox6_1.Size = New System.Drawing.Size(126, 70)
        Me.PictureBox6_1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage
        Me.PictureBox6_1.TabIndex = 44
        Me.PictureBox6_1.TabStop = False
        '
        'PictureBox7_2
        '
        Me.PictureBox7_2.Location = New System.Drawing.Point(821, 363)
        Me.PictureBox7_2.Name = "PictureBox7_2"
        Me.PictureBox7_2.Size = New System.Drawing.Size(126, 70)
        Me.PictureBox7_2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage
        Me.PictureBox7_2.TabIndex = 43
        Me.PictureBox7_2.TabStop = False
        '
        'PictureBox7_3
        '
        Me.PictureBox7_3.Location = New System.Drawing.Point(821, 287)
        Me.PictureBox7_3.Name = "PictureBox7_3"
        Me.PictureBox7_3.Size = New System.Drawing.Size(126, 70)
        Me.PictureBox7_3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage
        Me.PictureBox7_3.TabIndex = 42
        Me.PictureBox7_3.TabStop = False
        '
        'PictureBox6_3
        '
        Me.PictureBox6_3.Location = New System.Drawing.Point(689, 287)
        Me.PictureBox6_3.Name = "PictureBox6_3"
        Me.PictureBox6_3.Size = New System.Drawing.Size(126, 70)
        Me.PictureBox6_3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage
        Me.PictureBox6_3.TabIndex = 41
        Me.PictureBox6_3.TabStop = False
        '
        'PictureBox7_4
        '
        Me.PictureBox7_4.Location = New System.Drawing.Point(821, 211)
        Me.PictureBox7_4.Name = "PictureBox7_4"
        Me.PictureBox7_4.Size = New System.Drawing.Size(126, 70)
        Me.PictureBox7_4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage
        Me.PictureBox7_4.TabIndex = 40
        Me.PictureBox7_4.TabStop = False
        '
        'PictureBox6_2
        '
        Me.PictureBox6_2.Location = New System.Drawing.Point(689, 363)
        Me.PictureBox6_2.Name = "PictureBox6_2"
        Me.PictureBox6_2.Size = New System.Drawing.Size(126, 70)
        Me.PictureBox6_2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage
        Me.PictureBox6_2.TabIndex = 40
        Me.PictureBox6_2.TabStop = False
        '
        'PictureBox6_4
        '
        Me.PictureBox6_4.Location = New System.Drawing.Point(689, 211)
        Me.PictureBox6_4.Name = "PictureBox6_4"
        Me.PictureBox6_4.Size = New System.Drawing.Size(126, 70)
        Me.PictureBox6_4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage
        Me.PictureBox6_4.TabIndex = 39
        Me.PictureBox6_4.TabStop = False
        '
        'PictureBox7_5
        '
        Me.PictureBox7_5.Location = New System.Drawing.Point(821, 135)
        Me.PictureBox7_5.Name = "PictureBox7_5"
        Me.PictureBox7_5.Size = New System.Drawing.Size(126, 70)
        Me.PictureBox7_5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage
        Me.PictureBox7_5.TabIndex = 38
        Me.PictureBox7_5.TabStop = False
        '
        'PictureBox6_5
        '
        Me.PictureBox6_5.Location = New System.Drawing.Point(689, 135)
        Me.PictureBox6_5.Name = "PictureBox6_5"
        Me.PictureBox6_5.Size = New System.Drawing.Size(126, 70)
        Me.PictureBox6_5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage
        Me.PictureBox6_5.TabIndex = 37
        Me.PictureBox6_5.TabStop = False
        '
        'PictureBox4_0
        '
        Me.PictureBox4_0.Location = New System.Drawing.Point(425, 515)
        Me.PictureBox4_0.Name = "PictureBox4_0"
        Me.PictureBox4_0.Size = New System.Drawing.Size(126, 70)
        Me.PictureBox4_0.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage
        Me.PictureBox4_0.TabIndex = 36
        Me.PictureBox4_0.TabStop = False
        '
        'PictureBox5_1
        '
        Me.PictureBox5_1.Location = New System.Drawing.Point(557, 439)
        Me.PictureBox5_1.Name = "PictureBox5_1"
        Me.PictureBox5_1.Size = New System.Drawing.Size(126, 70)
        Me.PictureBox5_1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage
        Me.PictureBox5_1.TabIndex = 35
        Me.PictureBox5_1.TabStop = False
        '
        'PictureBox5_2
        '
        Me.PictureBox5_2.Location = New System.Drawing.Point(557, 363)
        Me.PictureBox5_2.Name = "PictureBox5_2"
        Me.PictureBox5_2.Size = New System.Drawing.Size(126, 70)
        Me.PictureBox5_2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage
        Me.PictureBox5_2.TabIndex = 34
        Me.PictureBox5_2.TabStop = False
        '
        'PictureBox5_3
        '
        Me.PictureBox5_3.Location = New System.Drawing.Point(557, 287)
        Me.PictureBox5_3.Name = "PictureBox5_3"
        Me.PictureBox5_3.Size = New System.Drawing.Size(126, 70)
        Me.PictureBox5_3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage
        Me.PictureBox5_3.TabIndex = 33
        Me.PictureBox5_3.TabStop = False
        '
        'PictureBox5_4
        '
        Me.PictureBox5_4.Location = New System.Drawing.Point(557, 211)
        Me.PictureBox5_4.Name = "PictureBox5_4"
        Me.PictureBox5_4.Size = New System.Drawing.Size(126, 70)
        Me.PictureBox5_4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage
        Me.PictureBox5_4.TabIndex = 32
        Me.PictureBox5_4.TabStop = False
        '
        'PictureBox5_5
        '
        Me.PictureBox5_5.Location = New System.Drawing.Point(557, 135)
        Me.PictureBox5_5.Name = "PictureBox5_5"
        Me.PictureBox5_5.Size = New System.Drawing.Size(126, 70)
        Me.PictureBox5_5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage
        Me.PictureBox5_5.TabIndex = 31
        Me.PictureBox5_5.TabStop = False
        '
        'PictureBox5_0
        '
        Me.PictureBox5_0.Location = New System.Drawing.Point(557, 515)
        Me.PictureBox5_0.Name = "PictureBox5_0"
        Me.PictureBox5_0.Size = New System.Drawing.Size(126, 70)
        Me.PictureBox5_0.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage
        Me.PictureBox5_0.TabIndex = 30
        Me.PictureBox5_0.TabStop = False
        '
        'PictureBox4_1
        '
        Me.PictureBox4_1.Location = New System.Drawing.Point(425, 439)
        Me.PictureBox4_1.Name = "PictureBox4_1"
        Me.PictureBox4_1.Size = New System.Drawing.Size(126, 70)
        Me.PictureBox4_1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage
        Me.PictureBox4_1.TabIndex = 29
        Me.PictureBox4_1.TabStop = False
        '
        'PictureBox4_2
        '
        Me.PictureBox4_2.Location = New System.Drawing.Point(425, 363)
        Me.PictureBox4_2.Name = "PictureBox4_2"
        Me.PictureBox4_2.Size = New System.Drawing.Size(126, 70)
        Me.PictureBox4_2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage
        Me.PictureBox4_2.TabIndex = 28
        Me.PictureBox4_2.TabStop = False
        '
        'PictureBox4_3
        '
        Me.PictureBox4_3.Location = New System.Drawing.Point(425, 287)
        Me.PictureBox4_3.Name = "PictureBox4_3"
        Me.PictureBox4_3.Size = New System.Drawing.Size(126, 70)
        Me.PictureBox4_3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage
        Me.PictureBox4_3.TabIndex = 27
        Me.PictureBox4_3.TabStop = False
        '
        'PictureBox4_4
        '
        Me.PictureBox4_4.Location = New System.Drawing.Point(425, 211)
        Me.PictureBox4_4.Name = "PictureBox4_4"
        Me.PictureBox4_4.Size = New System.Drawing.Size(126, 70)
        Me.PictureBox4_4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage
        Me.PictureBox4_4.TabIndex = 26
        Me.PictureBox4_4.TabStop = False
        '
        'PictureBox4_5
        '
        Me.PictureBox4_5.Location = New System.Drawing.Point(425, 135)
        Me.PictureBox4_5.Name = "PictureBox4_5"
        Me.PictureBox4_5.Size = New System.Drawing.Size(126, 70)
        Me.PictureBox4_5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage
        Me.PictureBox4_5.TabIndex = 25
        Me.PictureBox4_5.TabStop = False
        '
        'PictureBox3_0
        '
        Me.PictureBox3_0.Location = New System.Drawing.Point(293, 515)
        Me.PictureBox3_0.Name = "PictureBox3_0"
        Me.PictureBox3_0.Size = New System.Drawing.Size(126, 70)
        Me.PictureBox3_0.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage
        Me.PictureBox3_0.TabIndex = 24
        Me.PictureBox3_0.TabStop = False
        '
        'PictureBox3_1
        '
        Me.PictureBox3_1.Location = New System.Drawing.Point(293, 439)
        Me.PictureBox3_1.Name = "PictureBox3_1"
        Me.PictureBox3_1.Size = New System.Drawing.Size(126, 70)
        Me.PictureBox3_1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage
        Me.PictureBox3_1.TabIndex = 23
        Me.PictureBox3_1.TabStop = False
        '
        'PictureBox3_2
        '
        Me.PictureBox3_2.Location = New System.Drawing.Point(293, 363)
        Me.PictureBox3_2.Name = "PictureBox3_2"
        Me.PictureBox3_2.Size = New System.Drawing.Size(126, 70)
        Me.PictureBox3_2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage
        Me.PictureBox3_2.TabIndex = 22
        Me.PictureBox3_2.TabStop = False
        '
        'PictureBox3_3
        '
        Me.PictureBox3_3.Location = New System.Drawing.Point(293, 287)
        Me.PictureBox3_3.Name = "PictureBox3_3"
        Me.PictureBox3_3.Size = New System.Drawing.Size(126, 70)
        Me.PictureBox3_3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage
        Me.PictureBox3_3.TabIndex = 21
        Me.PictureBox3_3.TabStop = False
        '
        'PictureBox3_4
        '
        Me.PictureBox3_4.Location = New System.Drawing.Point(293, 211)
        Me.PictureBox3_4.Name = "PictureBox3_4"
        Me.PictureBox3_4.Size = New System.Drawing.Size(126, 70)
        Me.PictureBox3_4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage
        Me.PictureBox3_4.TabIndex = 20
        Me.PictureBox3_4.TabStop = False
        '
        'PictureBox3_5
        '
        Me.PictureBox3_5.Location = New System.Drawing.Point(293, 135)
        Me.PictureBox3_5.Name = "PictureBox3_5"
        Me.PictureBox3_5.Size = New System.Drawing.Size(126, 70)
        Me.PictureBox3_5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage
        Me.PictureBox3_5.TabIndex = 19
        Me.PictureBox3_5.TabStop = False
        '
        'PictureBox2_0
        '
        Me.PictureBox2_0.Location = New System.Drawing.Point(161, 515)
        Me.PictureBox2_0.Name = "PictureBox2_0"
        Me.PictureBox2_0.Size = New System.Drawing.Size(126, 70)
        Me.PictureBox2_0.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage
        Me.PictureBox2_0.TabIndex = 18
        Me.PictureBox2_0.TabStop = False
        '
        'PictureBox2_1
        '
        Me.PictureBox2_1.Location = New System.Drawing.Point(161, 439)
        Me.PictureBox2_1.Name = "PictureBox2_1"
        Me.PictureBox2_1.Size = New System.Drawing.Size(126, 70)
        Me.PictureBox2_1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage
        Me.PictureBox2_1.TabIndex = 17
        Me.PictureBox2_1.TabStop = False
        '
        'PictureBox2_2
        '
        Me.PictureBox2_2.Location = New System.Drawing.Point(161, 363)
        Me.PictureBox2_2.Name = "PictureBox2_2"
        Me.PictureBox2_2.Size = New System.Drawing.Size(126, 70)
        Me.PictureBox2_2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage
        Me.PictureBox2_2.TabIndex = 16
        Me.PictureBox2_2.TabStop = False
        '
        'PictureBox2_3
        '
        Me.PictureBox2_3.Location = New System.Drawing.Point(161, 287)
        Me.PictureBox2_3.Name = "PictureBox2_3"
        Me.PictureBox2_3.Size = New System.Drawing.Size(126, 70)
        Me.PictureBox2_3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage
        Me.PictureBox2_3.TabIndex = 15
        Me.PictureBox2_3.TabStop = False
        '
        'PictureBox2_4
        '
        Me.PictureBox2_4.Location = New System.Drawing.Point(161, 211)
        Me.PictureBox2_4.Name = "PictureBox2_4"
        Me.PictureBox2_4.Size = New System.Drawing.Size(126, 70)
        Me.PictureBox2_4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage
        Me.PictureBox2_4.TabIndex = 14
        Me.PictureBox2_4.TabStop = False
        '
        'PictureBox2_5
        '
        Me.PictureBox2_5.Location = New System.Drawing.Point(161, 135)
        Me.PictureBox2_5.Name = "PictureBox2_5"
        Me.PictureBox2_5.Size = New System.Drawing.Size(126, 70)
        Me.PictureBox2_5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage
        Me.PictureBox2_5.TabIndex = 13
        Me.PictureBox2_5.TabStop = False
        '
        'PictureBox1_0
        '
        Me.PictureBox1_0.Location = New System.Drawing.Point(29, 515)
        Me.PictureBox1_0.Name = "PictureBox1_0"
        Me.PictureBox1_0.Size = New System.Drawing.Size(126, 70)
        Me.PictureBox1_0.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage
        Me.PictureBox1_0.TabIndex = 12
        Me.PictureBox1_0.TabStop = False
        '
        'PictureBox1_1
        '
        Me.PictureBox1_1.Location = New System.Drawing.Point(29, 439)
        Me.PictureBox1_1.Name = "PictureBox1_1"
        Me.PictureBox1_1.Size = New System.Drawing.Size(126, 70)
        Me.PictureBox1_1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage
        Me.PictureBox1_1.TabIndex = 11
        Me.PictureBox1_1.TabStop = False
        '
        'PictureBox1_2
        '
        Me.PictureBox1_2.Location = New System.Drawing.Point(29, 363)
        Me.PictureBox1_2.Name = "PictureBox1_2"
        Me.PictureBox1_2.Size = New System.Drawing.Size(126, 70)
        Me.PictureBox1_2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage
        Me.PictureBox1_2.TabIndex = 10
        Me.PictureBox1_2.TabStop = False
        '
        'PictureBox1_3
        '
        Me.PictureBox1_3.Location = New System.Drawing.Point(29, 287)
        Me.PictureBox1_3.Name = "PictureBox1_3"
        Me.PictureBox1_3.Size = New System.Drawing.Size(126, 70)
        Me.PictureBox1_3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage
        Me.PictureBox1_3.TabIndex = 9
        Me.PictureBox1_3.TabStop = False
        '
        'PictureBox1_4
        '
        Me.PictureBox1_4.Location = New System.Drawing.Point(29, 211)
        Me.PictureBox1_4.Name = "PictureBox1_4"
        Me.PictureBox1_4.Size = New System.Drawing.Size(126, 70)
        Me.PictureBox1_4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage
        Me.PictureBox1_4.TabIndex = 8
        Me.PictureBox1_4.TabStop = False
        '
        'PictureBox1_5
        '
        Me.PictureBox1_5.Location = New System.Drawing.Point(29, 135)
        Me.PictureBox1_5.Name = "PictureBox1_5"
        Me.PictureBox1_5.Size = New System.Drawing.Size(126, 70)
        Me.PictureBox1_5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage
        Me.PictureBox1_5.TabIndex = 7
        Me.PictureBox1_5.TabStop = False
        '
        'lblPlayer1
        '
        Me.lblPlayer1.AutoSize = True
        Me.lblPlayer1.BackColor = System.Drawing.Color.Red
        Me.lblPlayer1.Font = New System.Drawing.Font("Palatino Linotype", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblPlayer1.Location = New System.Drawing.Point(26, 9)
        Me.lblPlayer1.Name = "lblPlayer1"
        Me.lblPlayer1.Size = New System.Drawing.Size(56, 18)
        Me.lblPlayer1.TabIndex = 48
        Me.lblPlayer1.Text = "Player 1"
        '
        'lblPlayer2
        '
        Me.lblPlayer2.AutoSize = True
        Me.lblPlayer2.BackColor = System.Drawing.Color.Yellow
        Me.lblPlayer2.Font = New System.Drawing.Font("Palatino Linotype", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblPlayer2.Location = New System.Drawing.Point(908, 9)
        Me.lblPlayer2.Name = "lblPlayer2"
        Me.lblPlayer2.Size = New System.Drawing.Size(56, 18)
        Me.lblPlayer2.TabIndex = 49
        Me.lblPlayer2.Text = "Player 2"
        '
        'frmconnect4
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(976, 611)
        Me.Controls.Add(Me.lblPlayer2)
        Me.Controls.Add(Me.lblPlayer1)
        Me.Controls.Add(Me.PictureBox7_0)
        Me.Controls.Add(Me.PictureBox6_0)
        Me.Controls.Add(Me.PictureBox7_1)
        Me.Controls.Add(Me.PictureBox6_1)
        Me.Controls.Add(Me.PictureBox7_2)
        Me.Controls.Add(Me.PictureBox7_3)
        Me.Controls.Add(Me.PictureBox6_3)
        Me.Controls.Add(Me.PictureBox7_4)
        Me.Controls.Add(Me.PictureBox6_2)
        Me.Controls.Add(Me.PictureBox6_4)
        Me.Controls.Add(Me.PictureBox7_5)
        Me.Controls.Add(Me.PictureBox6_5)
        Me.Controls.Add(Me.PictureBox4_0)
        Me.Controls.Add(Me.PictureBox5_1)
        Me.Controls.Add(Me.PictureBox5_2)
        Me.Controls.Add(Me.PictureBox5_3)
        Me.Controls.Add(Me.PictureBox5_4)
        Me.Controls.Add(Me.PictureBox5_5)
        Me.Controls.Add(Me.PictureBox5_0)
        Me.Controls.Add(Me.PictureBox4_1)
        Me.Controls.Add(Me.PictureBox4_2)
        Me.Controls.Add(Me.PictureBox4_3)
        Me.Controls.Add(Me.PictureBox4_4)
        Me.Controls.Add(Me.PictureBox4_5)
        Me.Controls.Add(Me.PictureBox3_0)
        Me.Controls.Add(Me.PictureBox3_1)
        Me.Controls.Add(Me.PictureBox3_2)
        Me.Controls.Add(Me.PictureBox3_3)
        Me.Controls.Add(Me.PictureBox3_4)
        Me.Controls.Add(Me.PictureBox3_5)
        Me.Controls.Add(Me.PictureBox2_0)
        Me.Controls.Add(Me.PictureBox2_1)
        Me.Controls.Add(Me.PictureBox2_2)
        Me.Controls.Add(Me.PictureBox2_3)
        Me.Controls.Add(Me.PictureBox2_4)
        Me.Controls.Add(Me.PictureBox2_5)
        Me.Controls.Add(Me.PictureBox1_0)
        Me.Controls.Add(Me.PictureBox1_1)
        Me.Controls.Add(Me.PictureBox1_2)
        Me.Controls.Add(Me.PictureBox1_3)
        Me.Controls.Add(Me.PictureBox1_4)
        Me.Controls.Add(Me.PictureBox1_5)
        Me.Controls.Add(Me.btnrow7)
        Me.Controls.Add(Me.btnrow6)
        Me.Controls.Add(Me.btnrow5)
        Me.Controls.Add(Me.btnrow4)
        Me.Controls.Add(Me.btnrow3)
        Me.Controls.Add(Me.btnrow2)
        Me.Controls.Add(Me.btnRow1)
        Me.Name = "frmconnect4"
        Me.Text = "Connect 4 board"
        CType(Me.PictureBox7_0, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox6_0, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox7_1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox6_1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox7_2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox7_3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox6_3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox7_4, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox6_2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox6_4, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox7_5, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox6_5, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox4_0, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox5_1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox5_2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox5_3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox5_4, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox5_5, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox5_0, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox4_1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox4_2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox4_3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox4_4, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox4_5, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox3_0, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox3_1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox3_2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox3_3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox3_4, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox3_5, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox2_0, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox2_1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox2_2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox2_3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox2_4, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox2_5, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox1_0, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox1_1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox1_2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox1_3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox1_4, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox1_5, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents btnRow1 As Button
    Friend WithEvents btnrow2 As Button
    Friend WithEvents btnrow3 As Button
    Friend WithEvents btnrow4 As Button
    Friend WithEvents btnrow5 As Button
    Friend WithEvents btnrow6 As Button
    Friend WithEvents btnrow7 As Button
    Friend WithEvents PictureBox1_5 As PictureBox
    Friend WithEvents PictureBox1_4 As PictureBox
    Friend WithEvents PictureBox1_3 As PictureBox
    Friend WithEvents PictureBox1_2 As PictureBox
    Friend WithEvents PictureBox1_1 As PictureBox
    Friend WithEvents PictureBox1_0 As PictureBox
    Friend WithEvents PictureBox2_5 As PictureBox
    Friend WithEvents PictureBox2_4 As PictureBox
    Friend WithEvents PictureBox2_3 As PictureBox
    Friend WithEvents PictureBox2_2 As PictureBox
    Friend WithEvents PictureBox2_1 As PictureBox
    Friend WithEvents PictureBox2_0 As PictureBox
    Friend WithEvents PictureBox3_5 As PictureBox
    Friend WithEvents PictureBox3_4 As PictureBox
    Friend WithEvents PictureBox3_3 As PictureBox
    Friend WithEvents PictureBox3_2 As PictureBox
    Friend WithEvents PictureBox3_1 As PictureBox
    Friend WithEvents PictureBox3_0 As PictureBox
    Friend WithEvents PictureBox4_5 As PictureBox
    Friend WithEvents PictureBox4_4 As PictureBox
    Friend WithEvents PictureBox4_3 As PictureBox
    Friend WithEvents PictureBox4_2 As PictureBox
    Friend WithEvents PictureBox4_1 As PictureBox
    Friend WithEvents PictureBox5_0 As PictureBox
    Friend WithEvents PictureBox5_5 As PictureBox
    Friend WithEvents PictureBox5_4 As PictureBox
    Friend WithEvents PictureBox5_3 As PictureBox
    Friend WithEvents PictureBox5_2 As PictureBox
    Friend WithEvents PictureBox5_1 As PictureBox
    Friend WithEvents PictureBox4_0 As PictureBox
    Friend WithEvents PictureBox6_5 As PictureBox
    Friend WithEvents PictureBox7_5 As PictureBox
    Friend WithEvents PictureBox6_4 As PictureBox
    Friend WithEvents PictureBox6_2 As PictureBox
    Friend WithEvents PictureBox7_4 As PictureBox
    Friend WithEvents PictureBox6_3 As PictureBox
    Friend WithEvents PictureBox7_3 As PictureBox
    Friend WithEvents PictureBox7_2 As PictureBox
    Friend WithEvents PictureBox6_1 As PictureBox
    Friend WithEvents PictureBox7_1 As PictureBox
    Friend WithEvents PictureBox6_0 As PictureBox
    Friend WithEvents PictureBox7_0 As PictureBox
    Friend WithEvents lblPlayer1 As Label
    Friend WithEvents lblPlayer2 As Label
End Class
